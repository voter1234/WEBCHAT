from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_socketio import SocketIO, emit, join_room, leave_room
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
from datetime import datetime
from storage import storage
from models import init_db
from auth import register_user, login_user, verify_user_email, get_user_by_token
import json

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SESSION_SECRET', 'echolink-secret-key')
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'pdf', 'txt', 'doc', 'docx'}

connected_users = {}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    result = register_user(data['username'], data['email'], data['password'])
    return jsonify(result)

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    result = login_user(data['username'], data['password'])
    return jsonify(result)

@app.route('/verify/<token>')
def verify_email(token):
    result = verify_user_email(token)
    if result['success']:
        return render_template('verified.html', message=result['message'])
    else:
        return render_template('verified.html', error=result['error'])

@app.route('/api/user', methods=['GET'])
def get_user():
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user = get_user_by_token(token)
    if user:
        return jsonify({
            'id': user['id'],
            'username': user['username'],
            'email': user['email'],
            'avatar': user['avatar'],
            'is_admin': user['is_admin'],
            'status': user['status']
        })
    return jsonify({'error': 'Unauthorized'}), 401

@app.route('/api/servers', methods=['GET', 'POST'])
def servers():
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user = get_user_by_token(token)
    
    if not user:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if request.method == 'POST':
        data = request.json
        new_server = storage.create_server(data['name'], user['id'])
        
        general_channel = storage.create_channel(
            server_id=new_server['id'],
            name='general',
            channel_type='text',
            position=0
        )
        voice_channel = storage.create_channel(
            server_id=new_server['id'],
            name='Voice Chat',
            channel_type='voice',
            position=1
        )
        
        return jsonify({
            'id': new_server['id'],
            'name': new_server['name'],
            'icon': new_server['icon'],
            'owner_id': new_server['owner_id']
        })
    else:
        user_servers = storage.get_user_servers(user['id'])
        return jsonify([{
            'id': s['id'],
            'name': s['name'],
            'icon': s['icon'],
            'owner_id': s['owner_id']
        } for s in user_servers])

@app.route('/api/servers/<int:server_id>/join', methods=['POST'])
def join_server(server_id):
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user = get_user_by_token(token)
    
    if not user:
        return jsonify({'error': 'Unauthorized'}), 401
    
    server = storage.get_server(server_id)
    if not server:
        return jsonify({'error': 'Server not found'}), 404
    
    storage.add_server_member(server_id, user['id'])
    return jsonify({'success': True})

@app.route('/api/servers/<int:server_id>/channels', methods=['GET', 'POST'])
def channels(server_id):
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user = get_user_by_token(token)
    
    if not user:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if request.method == 'POST':
        data = request.json
        new_channel = storage.create_channel(
            server_id=server_id,
            name=data['name'],
            channel_type=data.get('type', 'text')
        )
        
        return jsonify({
            'id': new_channel['id'],
            'name': new_channel['name'],
            'type': new_channel['type']
        })
    else:
        server_channels = storage.get_server_channels(server_id)
        return jsonify([{
            'id': c['id'],
            'name': c['name'],
            'type': c['type'],
            'server_id': c['server_id']
        } for c in server_channels])

@app.route('/api/channels/<int:channel_id>/messages', methods=['GET'])
def get_messages(channel_id):
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user = get_user_by_token(token)
    
    if not user:
        return jsonify({'error': 'Unauthorized'}), 401
    
    messages = storage.get_channel_messages(channel_id)
    result = []
    
    for m in messages:
        author = storage.get_user_by_id(m['user_id'])
        result.append({
            'id': m['id'],
            'content': m['content'],
            'author': {
                'id': author['id'],
                'username': author['username'],
                'avatar': author['avatar']
            },
            'timestamp': m['timestamp'],
            'attachments': m.get('attachments')
        })
    
    return jsonify(result)

@app.route('/api/upload', methods=['POST'])
def upload_file():
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user = get_user_by_token(token)
    
    if not user:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        filename = f"{timestamp}_{filename}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        return jsonify({'url': f'/static/uploads/{filename}'})
    
    return jsonify({'error': 'Invalid file'}), 400

@app.route('/api/admin/users', methods=['GET', 'DELETE'])
def admin_users():
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user = get_user_by_token(token)
    
    if not user or not user['is_admin']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    if request.method == 'DELETE':
        user_id = request.json.get('user_id')
        storage.delete_user(user_id)
        return jsonify({'success': True})
    else:
        users = storage.get_all_users()
        return jsonify([{
            'id': u['id'],
            'username': u['username'],
            'email': u['email'],
            'is_verified': u['is_verified'],
            'is_admin': u['is_admin'],
            'status': u['status'],
            'created_at': u['created_at']
        } for u in users])

@app.route('/api/admin/servers', methods=['GET', 'DELETE'])
def admin_servers():
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    user = get_user_by_token(token)
    
    if not user or not user['is_admin']:
        return jsonify({'error': 'Unauthorized'}), 403
    
    if request.method == 'DELETE':
        server_id = request.json.get('server_id')
        storage.delete_server(server_id)
        return jsonify({'success': True})
    else:
        servers = storage.get_all_servers()
        return jsonify([{
            'id': s['id'],
            'name': s['name'],
            'owner_id': s['owner_id'],
            'created_at': s['created_at'],
            'member_count': storage.get_server_member_count(s['id'])
        } for s in servers])

@socketio.on('connect')
def handle_connect():
    print(f'Client connected: {request.sid}')

@socketio.on('authenticate')
def handle_authenticate(data):
    token = data.get('token')
    user = get_user_by_token(token)
    
    if user:
        connected_users[request.sid] = user['id']
        storage.update_user(user['id'], {'status': 'online'})
        
        emit('authenticated', {'user_id': user['id'], 'username': user['username']})
        socketio.emit('user_status', {'user_id': user['id'], 'status': 'online'}, broadcast=True)

@socketio.on('disconnect')
def handle_disconnect():
    user_id = connected_users.pop(request.sid, None)
    if user_id:
        storage.update_user(user_id, {'status': 'offline'})
        socketio.emit('user_status', {'user_id': user_id, 'status': 'offline'}, broadcast=True)

@socketio.on('join_channel')
def handle_join_channel(data):
    channel_id = data.get('channel_id')
    join_room(f'channel_{channel_id}')
    emit('joined_channel', {'channel_id': channel_id})

@socketio.on('leave_channel')
def handle_leave_channel(data):
    channel_id = data.get('channel_id')
    leave_room(f'channel_{channel_id}')

@socketio.on('send_message')
def handle_message(data):
    user_id = connected_users.get(request.sid)
    if not user_id:
        return
    
    message = storage.create_message(
        channel_id=data['channel_id'],
        user_id=user_id,
        content=data['content'],
        attachments=data.get('attachments')
    )
    
    user = storage.get_user_by_id(user_id)
    
    message_data = {
        'id': message['id'],
        'content': message['content'],
        'channel_id': message['channel_id'],
        'author': {
            'id': user['id'],
            'username': user['username'],
            'avatar': user['avatar']
        },
        'timestamp': message['timestamp'],
        'attachments': message.get('attachments')
    }
    
    socketio.emit('new_message', message_data, room=f'channel_{data["channel_id"]}')

@socketio.on('typing')
def handle_typing(data):
    user_id = connected_users.get(request.sid)
    if not user_id:
        return
    
    user = storage.get_user_by_id(user_id)
    emit('user_typing', {
        'user_id': user['id'],
        'username': user['username'],
        'channel_id': data['channel_id']
    }, room=f'channel_{data["channel_id"]}', include_self=False)

@socketio.on('voice_signal')
def handle_voice_signal(data):
    emit('voice_signal', data, room=f'channel_{data["channel_id"]}', include_self=False)

if __name__ == '__main__':
    os.makedirs('static/uploads', exist_ok=True)
    init_db()
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
