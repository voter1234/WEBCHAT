import json
import os
import tempfile
from datetime import datetime
from threading import Lock
import fcntl

class JSONStorage:
    def __init__(self, data_file='data/echolink_data.json'):
        self.data_file = data_file
        self.lock_file = data_file + '.lock'
        self.thread_lock = Lock()
        self._ensure_data_dir()
        self._init_data()
    
    def _ensure_data_dir(self):
        os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
    
    def _init_data(self):
        if not os.path.exists(self.data_file):
            initial_data = {
                'users': [],
                'servers': [],
                'channels': [],
                'messages': [],
                'direct_messages': [],
                'server_members': [],
                'counters': {
                    'user_id': 1,
                    'server_id': 1,
                    'channel_id': 1,
                    'message_id': 1,
                    'dm_id': 1
                }
            }
            with open(self.data_file, 'w') as f:
                json.dump(initial_data, f, indent=2)
    
    def _execute_with_lock(self, callback):
        with self.thread_lock:
            lock_fd = os.open(self.lock_file, os.O_CREAT | os.O_RDWR)
            try:
                fcntl.flock(lock_fd, fcntl.LOCK_EX)
                try:
                    with open(self.data_file, 'r') as f:
                        data = json.load(f)
                    
                    result = callback(data)
                    
                    if result.get('save', False):
                        temp_fd, temp_path = tempfile.mkstemp(dir=os.path.dirname(self.data_file), text=True)
                        try:
                            with os.fdopen(temp_fd, 'w') as temp_file:
                                json.dump(data, temp_file, indent=2)
                                temp_file.flush()
                                os.fsync(temp_file.fileno())
                            os.replace(temp_path, self.data_file)
                        except:
                            if os.path.exists(temp_path):
                                os.unlink(temp_path)
                            raise
                    
                    return result.get('value')
                finally:
                    fcntl.flock(lock_fd, fcntl.LOCK_UN)
            finally:
                os.close(lock_fd)
    
    def create_user(self, username, email, password_hash, is_verified=False, is_admin=False, verification_token=None):
        def callback(data):
            for user in data['users']:
                if user['username'] == username or user['email'] == email:
                    return {'save': False, 'value': None}
            
            user = {
                'id': data['counters']['user_id'],
                'username': username,
                'email': email,
                'password_hash': password_hash,
                'is_verified': is_verified,
                'is_admin': is_admin,
                'avatar': 'default.png',
                'status': 'offline',
                'verification_token': verification_token,
                'created_at': datetime.utcnow().isoformat()
            }
            
            data['counters']['user_id'] += 1
            data['users'].append(user)
            return {'save': True, 'value': user}
        
        return self._execute_with_lock(callback)
    
    def get_user_by_username(self, username):
        def callback(data):
            for user in data['users']:
                if user['username'] == username:
                    return {'save': False, 'value': user.copy()}
            return {'save': False, 'value': None}
        
        return self._execute_with_lock(callback)
    
    def get_user_by_id(self, user_id):
        def callback(data):
            for user in data['users']:
                if user['id'] == user_id:
                    return {'save': False, 'value': user.copy()}
            return {'save': False, 'value': None}
        
        return self._execute_with_lock(callback)
    
    def get_user_by_verification_token(self, token):
        def callback(data):
            for user in data['users']:
                if user.get('verification_token') == token:
                    return {'save': False, 'value': user.copy()}
            return {'save': False, 'value': None}
        
        return self._execute_with_lock(callback)
    
    def update_user(self, user_id, updates):
        def callback(data):
            for user in data['users']:
                if user['id'] == user_id:
                    user.update(updates)
                    return {'save': True, 'value': user.copy()}
            return {'save': False, 'value': None}
        
        return self._execute_with_lock(callback)
    
    def get_all_users(self):
        def callback(data):
            return {'save': False, 'value': [u.copy() for u in data['users']]}
        
        return self._execute_with_lock(callback)
    
    def delete_user(self, user_id):
        def callback(data):
            data['users'] = [u for u in data['users'] if u['id'] != user_id]
            data['messages'] = [m for m in data['messages'] if m['user_id'] != user_id]
            data['server_members'] = [sm for sm in data['server_members'] if sm['user_id'] != user_id]
            return {'save': True, 'value': None}
        
        return self._execute_with_lock(callback)
    
    def create_server(self, name, owner_id):
        def callback(data):
            server = {
                'id': data['counters']['server_id'],
                'name': name,
                'owner_id': owner_id,
                'icon': 'default_server.png',
                'created_at': datetime.utcnow().isoformat()
            }
            
            data['counters']['server_id'] += 1
            data['servers'].append(server)
            
            data['server_members'].append({
                'server_id': server['id'],
                'user_id': owner_id,
                'joined_at': datetime.utcnow().isoformat()
            })
            
            return {'save': True, 'value': server.copy()}
        
        return self._execute_with_lock(callback)
    
    def get_server(self, server_id):
        def callback(data):
            for server in data['servers']:
                if server['id'] == server_id:
                    return {'save': False, 'value': server.copy()}
            return {'save': False, 'value': None}
        
        return self._execute_with_lock(callback)
    
    def get_user_servers(self, user_id):
        def callback(data):
            server_ids = [sm['server_id'] for sm in data['server_members'] if sm['user_id'] == user_id]
            servers = [s.copy() for s in data['servers'] if s['id'] in server_ids]
            return {'save': False, 'value': servers}
        
        return self._execute_with_lock(callback)
    
    def get_all_servers(self):
        def callback(data):
            return {'save': False, 'value': [s.copy() for s in data['servers']]}
        
        return self._execute_with_lock(callback)
    
    def delete_server(self, server_id):
        def callback(data):
            channel_ids = [c['id'] for c in data['channels'] if c['server_id'] == server_id]
            
            data['servers'] = [s for s in data['servers'] if s['id'] != server_id]
            data['channels'] = [c for c in data['channels'] if c['server_id'] != server_id]
            data['server_members'] = [sm for sm in data['server_members'] if sm['server_id'] != server_id]
            data['messages'] = [m for m in data['messages'] if m['channel_id'] not in channel_ids]
            
            return {'save': True, 'value': None}
        
        return self._execute_with_lock(callback)
    
    def add_server_member(self, server_id, user_id):
        def callback(data):
            for sm in data['server_members']:
                if sm['server_id'] == server_id and sm['user_id'] == user_id:
                    return {'save': False, 'value': False}
            
            data['server_members'].append({
                'server_id': server_id,
                'user_id': user_id,
                'joined_at': datetime.utcnow().isoformat()
            })
            return {'save': True, 'value': True}
        
        return self._execute_with_lock(callback)
    
    def get_server_member_count(self, server_id):
        def callback(data):
            count = len([sm for sm in data['server_members'] if sm['server_id'] == server_id])
            return {'save': False, 'value': count}
        
        return self._execute_with_lock(callback)
    
    def create_channel(self, server_id, name, channel_type='text', position=0):
        def callback(data):
            channel = {
                'id': data['counters']['channel_id'],
                'server_id': server_id,
                'name': name,
                'type': channel_type,
                'position': position,
                'created_at': datetime.utcnow().isoformat()
            }
            
            data['counters']['channel_id'] += 1
            data['channels'].append(channel)
            return {'save': True, 'value': channel.copy()}
        
        return self._execute_with_lock(callback)
    
    def get_server_channels(self, server_id):
        def callback(data):
            channels = [c.copy() for c in data['channels'] if c['server_id'] == server_id]
            channels = sorted(channels, key=lambda x: x['position'])
            return {'save': False, 'value': channels}
        
        return self._execute_with_lock(callback)
    
    def get_channel(self, channel_id):
        def callback(data):
            for channel in data['channels']:
                if channel['id'] == channel_id:
                    return {'save': False, 'value': channel.copy()}
            return {'save': False, 'value': None}
        
        return self._execute_with_lock(callback)
    
    def create_message(self, channel_id, user_id, content, attachments=None):
        def callback(data):
            message = {
                'id': data['counters']['message_id'],
                'channel_id': channel_id,
                'user_id': user_id,
                'content': content,
                'timestamp': datetime.utcnow().isoformat(),
                'attachments': attachments
            }
            
            data['counters']['message_id'] += 1
            data['messages'].append(message)
            return {'save': True, 'value': message.copy()}
        
        return self._execute_with_lock(callback)
    
    def get_channel_messages(self, channel_id, limit=100):
        def callback(data):
            messages = [m.copy() for m in data['messages'] if m['channel_id'] == channel_id]
            messages = sorted(messages, key=lambda x: x['timestamp'])
            return {'save': False, 'value': messages[-limit:]}
        
        return self._execute_with_lock(callback)
    
    def create_direct_message(self, sender_id, receiver_id, content):
        def callback(data):
            dm = {
                'id': data['counters']['dm_id'],
                'sender_id': sender_id,
                'receiver_id': receiver_id,
                'content': content,
                'timestamp': datetime.utcnow().isoformat(),
                'is_read': False
            }
            
            data['counters']['dm_id'] += 1
            data['direct_messages'].append(dm)
            return {'save': True, 'value': dm.copy()}
        
        return self._execute_with_lock(callback)

storage = JSONStorage()
