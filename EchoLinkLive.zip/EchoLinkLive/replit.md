# EchoLink - Discord Clone

## Overview
EchoLink is a full-featured Discord clone built with Python Flask backend and vanilla JavaScript frontend. It provides real-time text and voice chat, server management, and admin controls.

## Features
- User registration and login with SMTP email verification
- Real-time text chat using WebSockets
- Voice chat with WebRTC
- Server and channel creation/management
- Admin dashboard for platform oversight
- Direct messaging
- File and image sharing
- Discord-like UI with familiar layout

## Tech Stack
- **Backend**: Flask, Flask-SocketIO
- **Storage**: JSON files (simple and portable)
- **Real-time**: WebSockets (Socket.IO)
- **Voice**: WebRTC (aiortc)
- **Authentication**: JWT, bcrypt
- **Email**: SMTP (smtplib)

## Project Structure
- `app.py` - Main Flask application and WebSocket handlers
- `storage.py` - JSON-based data storage layer
- `models.py` - Data model definitions
- `auth.py` - Authentication and email verification
- `data/echolink_data.json` - JSON data storage file
- `static/` - Frontend assets (CSS, JS, images)
- `templates/` - HTML templates
- `static/uploads/` - User-uploaded files and avatars

## Data Schema (JSON Storage)
- Users (id, username, email, password_hash, is_verified, is_admin, avatar, status)
- Servers (id, name, owner_id, icon, created_at)
- Channels (id, server_id, name, type [text/voice], position)
- Messages (id, channel_id, user_id, content, timestamp, attachments)
- ServerMembers (server_id, user_id, joined_at)
- DirectMessages (id, sender_id, receiver_id, content, timestamp)

All data stored in `data/echolink_data.json` with thread-safe file locking.

## Recent Changes
- **October 23, 2025** - Switched to JSON file storage
  - Replaced PostgreSQL/SQLite with simple JSON file storage
  - More portable and easier to backup/restore
  - No database setup required
  - Thread-safe file operations with locking
  - All data in `data/echolink_data.json`
  
- **October 23, 2025** - Complete implementation delivered
  - Full Discord clone with all requested features
  - User authentication with SMTP email verification
  - Real-time text chat via WebSockets
  - Voice chat using WebRTC
  - Server and channel management
  - Admin dashboard with full controls
  - Discord-like UI with gradient login page
  - File sharing and image attachments
  - Comprehensive README documentation
  - Admin account created (admin/admin123)

## User Preferences
None documented yet

## Architecture Decisions
- Using Flask-SocketIO for WebSocket support (easier than raw WebSockets)
- JSON file storage for simplicity and portability (easy to backup/restore)
- Thread-safe file locking for concurrent access
- JWT for stateless authentication
- Eventlet for async WebSocket handling
- Discord color scheme: #2C2F33, #23272A, #7289DA, #99AAB5
