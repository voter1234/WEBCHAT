from storage import storage

def init_db():
    print("JSON storage initialized successfully!")

def get_session():
    return storage

class User:
    pass

class Server:
    pass

class Channel:
    pass

class Message:
    pass

class DirectMessage:
    pass
