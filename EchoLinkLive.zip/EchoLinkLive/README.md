# EchoLink - Discord Clone

A full-featured Discord clone built with Python Flask and vanilla JavaScript, featuring real-time chat, voice communication, and server management.

![EchoLink Login](https://img.shields.io/badge/Status-Production%20Ready-green)

## Features

### User Features
- **Authentication System**
  - User registration with email verification via SMTP
  - Secure login with JWT tokens
  - Password hashing with bcrypt
  - Email verification workflow

- **Real-time Text Chat**
  - WebSocket-based instant messaging
  - Message history persistence
  - Typing indicators
  - File and image sharing
  - Message attachments

- **Voice Chat**
  - WebRTC-based voice communication
  - Low-latency audio streaming
  - Join/leave voice channels
  - Automatic echo cancellation and noise suppression

- **Server Management**
  - Create unlimited servers
  - Join servers
  - Multiple text and voice channels per server
  - Server ownership and member management

- **User Profiles**
  - Custom avatars
  - Online/offline status
  - User presence tracking

### Admin Features
- **Admin Dashboard**
  - View all users and servers
  - Delete users and servers
  - Monitor platform activity
  - User verification status

## Technology Stack

### Backend
- **Flask** - Web framework
- **Flask-SocketIO** - WebSocket support for real-time communication
- **JSON Files** - Simple file-based data storage
- **bcrypt** - Password hashing
- **JWT** - Token-based authentication
- **SMTP** - Email verification

### Frontend
- **Vanilla JavaScript** - No framework dependencies
- **Socket.IO Client** - WebSocket client
- **WebRTC** - Voice chat
- **CSS3** - Discord-inspired UI design

## Installation

### Prerequisites
- Python 3.11+
- SMTP server credentials (optional, for email verification)

### Setup

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd echolink
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure environment variables (optional)**
   
   For email verification, set these optional variables:
   ```bash
   export SMTP_SERVER=smtp.gmail.com
   export SMTP_PORT=587
   export SMTP_USER=your-email@gmail.com
   export SMTP_PASSWORD=your-app-password
   ```

4. **Create an admin account**
   ```bash
   python create_admin.py
   ```
   
   Default credentials:
   - Username: `admin`
   - Password: `admin123`
   - Email: `admin@echolink.local`

5. **Run the application**
   ```bash
   python app.py
   ```

6. **Access the application**
   
   Open your browser and navigate to `http://localhost:5000`

## Usage Guide

### For Regular Users

1. **Registration**
   - Click "Register" on the login page
   - Enter your email, username, and password
   - Check your email for verification link
   - Click the verification link
   - Log in with your credentials

2. **Creating a Server**
   - Click the "+" button in the servers sidebar
   - Enter a server name
   - Your server is created with default "general" text and voice channels

3. **Chatting**
   - Select a server from the left sidebar
   - Choose a text channel
   - Type your message and press Enter or click Send
   - Upload files using the attachment button

4. **Voice Chat**
   - Select a voice channel
   - Click "Join Voice" button
   - Grant microphone permissions
   - Your microphone will be active in the channel
   - Click "Leave Voice" to disconnect

### For Administrators

1. **Access Admin Panel**
   - Log in with admin credentials
   - Click the settings icon (⚙️) in the bottom bar
   - View and manage all users and servers

2. **User Management**
   - View all registered users
   - See verification status
   - Delete problematic users

3. **Server Management**
   - View all servers
   - See member counts
   - Delete servers if needed

## API Endpoints

### Authentication
- `POST /api/register` - Register new user
- `POST /api/login` - User login
- `GET /verify/<token>` - Verify email address
- `GET /api/user` - Get current user info

### Servers
- `GET /api/servers` - Get user's servers
- `POST /api/servers` - Create new server
- `POST /api/servers/<id>/join` - Join a server

### Channels
- `GET /api/servers/<id>/channels` - Get server channels
- `POST /api/servers/<id>/channels` - Create new channel
- `GET /api/channels/<id>/messages` - Get channel messages

### Admin
- `GET /api/admin/users` - Get all users (admin only)
- `DELETE /api/admin/users` - Delete user (admin only)
- `GET /api/admin/servers` - Get all servers (admin only)
- `DELETE /api/admin/servers` - Delete server (admin only)

### Uploads
- `POST /api/upload` - Upload file/image

## WebSocket Events

### Client → Server
- `authenticate` - Authenticate with JWT token
- `join_channel` - Join a text/voice channel
- `leave_channel` - Leave a channel
- `send_message` - Send a chat message
- `typing` - Indicate user is typing
- `voice_signal` - WebRTC signaling for voice chat

### Server → Client
- `authenticated` - Confirmation of authentication
- `new_message` - New message in channel
- `user_typing` - User is typing indicator
- `user_status` - User online/offline status change
- `voice_signal` - WebRTC signaling from other users

## Project Structure

```
echolink/
├── app.py                 # Main Flask application & WebSocket handlers
├── storage.py             # JSON-based data storage layer
├── models.py              # Data model definitions
├── auth.py                # Authentication & email verification
├── create_admin.py        # Script to create admin user
├── requirements.txt       # Python dependencies
├── data/
│   └── echolink_data.json # JSON data storage file
├── static/
│   ├── css/
│   │   └── style.css      # Discord-inspired styling
│   ├── js/
│   │   ├── app.js         # Main frontend application
│   │   └── voice.js       # WebRTC voice chat
│   ├── images/
│   │   └── default.png    # Default avatar
│   └── uploads/           # User-uploaded files
└── templates/
    ├── index.html         # Main application page
    └── verified.html      # Email verification page
```

## Data Storage

All data is stored in a simple JSON file at `data/echolink_data.json`. The file contains:

### Users
- `id` - Unique identifier
- `username` - Unique username
- `email` - Unique email address
- `password_hash` - Bcrypt hashed password
- `is_verified` - Email verification status
- `is_admin` - Admin privileges flag
- `avatar` - Avatar filename
- `status` - Online/offline status
- `verification_token` - Email verification token

### Servers
- `id` - Unique identifier
- `name` - Server name
- `owner_id` - User ID of owner
- `icon` - Server icon filename
- `created_at` - Creation timestamp

### Channels
- `id` - Unique identifier
- `server_id` - Server ID
- `name` - Channel name
- `type` - 'text' or 'voice'
- `position` - Display order

### Messages
- `id` - Unique identifier
- `channel_id` - Channel ID
- `user_id` - User ID
- `content` - Message text
- `timestamp` - Message timestamp
- `attachments` - Attached file URL

### DirectMessages
- `id` - Unique identifier
- `sender_id` - User ID
- `receiver_id` - User ID
- `content` - Message text
- `timestamp` - Message timestamp
- `is_read` - Read status

### Data File Management

The JSON data file is thread-safe with locking mechanisms. To backup your data:
```bash
cp data/echolink_data.json data/echolink_data_backup.json
```

To reset all data:
```bash
rm data/echolink_data.json
python create_admin.py
```

## Email Configuration

### Using Gmail

1. Enable 2-Factor Authentication on your Google account
2. Generate an App Password:
   - Go to Google Account Settings
   - Security → 2-Step Verification → App Passwords
   - Generate a new app password
3. Use these credentials:
   ```bash
   SMTP_SERVER=smtp.gmail.com
   SMTP_PORT=587
   SMTP_USER=your-email@gmail.com
   SMTP_PASSWORD=your-app-password
   ```

### Development Mode

Without SMTP configuration, verification links will be printed to the console:
```
EMAIL VERIFICATION (Development Mode):
To: user@example.com
Verification Link: http://localhost:5000/verify/abc123...
Token: abc123...
```

## Security Features

- **Password Security**: Bcrypt hashing with salt
- **Token Security**: JWT with expiration
- **CSRF Protection**: Secure token handling
- **SQL Injection Protection**: SQLAlchemy ORM
- **XSS Protection**: HTML escaping in frontend
- **File Upload Security**: File type validation and secure filenames

## Performance Optimizations

- **WebSocket Connection**: Persistent connection for real-time updates
- **Message Pagination**: Limited message history loading
- **Eventlet**: Async WebSocket handling
- **Database Indexing**: Optimized queries with proper indexes

## Browser Compatibility

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

**Note**: Voice chat requires WebRTC support and microphone permissions.

## Known Limitations

1. **Voice Chat**: Basic P2P WebRTC implementation. For production use with many users, consider implementing a media server (like Janus or mediasoup).

2. **Direct Messaging**: Basic implementation provided. Full DM interface can be expanded.

3. **File Storage**: Files stored locally. For production, use cloud storage (S3, etc.).

4. **Data Storage**: JSON file-based storage is simple but not suitable for high-traffic production use. For production, consider using a proper database like PostgreSQL or MongoDB.

5. **Scalability**: Single server deployment with file-based storage. For high traffic, implement a proper database and load balancing.

## Future Enhancements

- Video chat support
- Screen sharing
- Message reactions and emojis
- Message editing and deletion
- Rich text formatting (markdown)
- User roles and permissions
- Server invites and invite links
- Notification system
- Search functionality
- Message threads
- Custom themes

## Troubleshooting

### Port Already in Use
```bash
# Find and kill the process using port 5000
lsof -ti:5000 | xargs kill -9
```

### Data File Issues
- Data file is created automatically at `data/echolink_data.json`
- To reset: `rm data/echolink_data.json` and restart the app
- To backup: `cp data/echolink_data.json data/backup.json`
- Check file permissions if encountering write errors

### WebSocket Connection Failed
- Check firewall settings
- Verify server is running on 0.0.0.0
- Check browser console for errors

### Voice Chat Not Working
- Grant microphone permissions in browser
- Check browser WebRTC support
- Verify HTTPS (required for production WebRTC)

## License

This project is created for educational and personal use.

## Credits

Inspired by Discord's excellent user interface and communication features.

## Support

For issues, questions, or contributions, please open an issue in the repository.

---

**Note**: Remember to change the default admin password in production and configure proper SMTP credentials for email verification.
