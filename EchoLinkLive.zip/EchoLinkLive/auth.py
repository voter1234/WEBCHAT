import bcrypt
import jwt
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
import os
import secrets
from storage import storage

SECRET_KEY = os.getenv('SESSION_SECRET', 'echolink-secret-key-change-in-production')

def hash_password(password):
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

def verify_password(password, password_hash):
    return bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8'))

def generate_token(user_id):
    payload = {
        'user_id': user_id,
        'exp': datetime.utcnow() + timedelta(days=30)
    }
    return jwt.encode(payload, SECRET_KEY, algorithm='HS256')

def verify_token(token):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        return payload['user_id']
    except:
        return None

def generate_verification_token():
    return secrets.token_urlsafe(32)

def send_verification_email(email, username, verification_token, smtp_server='smtp.gmail.com', smtp_port=587, smtp_user=None, smtp_password=None):
    try:
        verification_link = f"http://localhost:5000/verify/{verification_token}"
        
        msg = MIMEMultipart('alternative')
        msg['Subject'] = 'Verify your EchoLink account'
        msg['From'] = smtp_user or 'noreply@echolink.local'
        msg['To'] = email
        
        text = f"""
        Welcome to EchoLink, {username}!
        
        Please verify your email address by clicking the link below:
        {verification_link}
        
        If you didn't create this account, please ignore this email.
        
        Thanks,
        The EchoLink Team
        """
        
        html = f"""
        <html>
          <body style="font-family: Arial, sans-serif; padding: 20px; background-color: #2C2F33; color: #99AAB5;">
            <div style="max-width: 600px; margin: 0 auto; background-color: #23272A; padding: 30px; border-radius: 8px;">
              <h2 style="color: #7289DA;">Welcome to EchoLink!</h2>
              <p>Hi {username},</p>
              <p>Thanks for joining EchoLink! Please verify your email address to get started.</p>
              <p style="text-align: center; margin: 30px 0;">
                <a href="{verification_link}" style="background-color: #7289DA; color: white; padding: 12px 30px; text-decoration: none; border-radius: 4px; display: inline-block;">Verify Email</a>
              </p>
              <p style="color: #72767D; font-size: 12px;">If you didn't create this account, please ignore this email.</p>
            </div>
          </body>
        </html>
        """
        
        part1 = MIMEText(text, 'plain')
        part2 = MIMEText(html, 'html')
        msg.attach(part1)
        msg.attach(part2)
        
        if smtp_user and smtp_password:
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.starttls()
                server.login(smtp_user, smtp_password)
                server.send_message(msg)
            return True
        else:
            print(f"EMAIL VERIFICATION (Development Mode):")
            print(f"To: {email}")
            print(f"Verification Link: {verification_link}")
            print(f"Token: {verification_token}")
            return True
    except Exception as e:
        print(f"Email error: {e}")
        return False

def register_user(username, email, password, smtp_config=None):
    try:
        password_hash = hash_password(password)
        verification_token = generate_verification_token()
        
        new_user = storage.create_user(
            username=username,
            email=email,
            password_hash=password_hash,
            verification_token=verification_token,
            is_verified=False
        )
        
        if not new_user:
            return {'success': False, 'error': 'Username or email already exists'}
        
        if smtp_config:
            send_verification_email(email, username, verification_token, **smtp_config)
        else:
            send_verification_email(email, username, verification_token)
        
        return {'success': True, 'message': 'Account created! Please check your email for verification.'}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def login_user(username, password):
    try:
        user = storage.get_user_by_username(username)
        
        if not user:
            return {'success': False, 'error': 'Invalid username or password'}
        
        if not verify_password(password, user['password_hash']):
            return {'success': False, 'error': 'Invalid username or password'}
        
        if not user['is_verified']:
            return {'success': False, 'error': 'Please verify your email first'}
        
        token = generate_token(user['id'])
        
        return {
            'success': True,
            'token': token,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
                'avatar': user['avatar'],
                'is_admin': user['is_admin']
            }
        }
    except Exception as e:
        return {'success': False, 'error': str(e)}

def verify_user_email(verification_token):
    try:
        user = storage.get_user_by_verification_token(verification_token)
        
        if not user:
            return {'success': False, 'error': 'Invalid verification token'}
        
        storage.update_user(user['id'], {
            'is_verified': True,
            'verification_token': None
        })
        
        return {'success': True, 'message': 'Email verified successfully! You can now log in.'}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def get_user_by_token(token):
    user_id = verify_token(token)
    if not user_id:
        return None
    
    return storage.get_user_by_id(user_id)
