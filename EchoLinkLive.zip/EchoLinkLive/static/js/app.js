let token = localStorage.getItem('echolink_token');
let currentUser = null;
let socket = null;
let currentServer = null;
let currentChannel = null;
let typingTimeout = null;

const authContainer = document.getElementById('auth-container');
const appContainer = document.getElementById('app-container');
const authMessage = document.getElementById('auth-message');

if (token) {
    verifyAndLoadApp();
} else {
    authContainer.style.display = 'flex';
}

document.getElementById('show-register').addEventListener('click', (e) => {
    e.preventDefault();
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
    authMessage.style.display = 'none';
});

document.getElementById('show-login').addEventListener('click', (e) => {
    e.preventDefault();
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('login-form').style.display = 'block';
    authMessage.style.display = 'none';
});

document.getElementById('register-btn').addEventListener('click', async () => {
    const email = document.getElementById('register-email').value;
    const username = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;
    
    if (!email || !username || !password) {
        showMessage('Please fill in all fields', 'error');
        return;
    }
    
    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({email, username, password})
        });
        
        const data = await response.json();
        
        if (data.success) {
            showMessage(data.message, 'success');
            setTimeout(() => {
                document.getElementById('register-form').style.display = 'none';
                document.getElementById('login-form').style.display = 'block';
            }, 2000);
        } else {
            showMessage(data.error, 'error');
        }
    } catch (error) {
        showMessage('Registration failed', 'error');
    }
});

document.getElementById('login-btn').addEventListener('click', async () => {
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    
    if (!username || !password) {
        showMessage('Please fill in all fields', 'error');
        return;
    }
    
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({username, password})
        });
        
        const data = await response.json();
        
        if (data.success) {
            token = data.token;
            localStorage.setItem('echolink_token', token);
            currentUser = data.user;
            loadApp();
        } else {
            showMessage(data.error, 'error');
        }
    } catch (error) {
        showMessage('Login failed', 'error');
    }
});

document.getElementById('logout-btn').addEventListener('click', () => {
    localStorage.removeItem('echolink_token');
    if (socket) socket.disconnect();
    location.reload();
});

function showMessage(message, type) {
    authMessage.textContent = message;
    authMessage.className = type;
    authMessage.style.display = 'block';
    setTimeout(() => {
        authMessage.style.display = 'none';
    }, 5000);
}

async function verifyAndLoadApp() {
    try {
        const response = await fetch('/api/user', {
            headers: {'Authorization': `Bearer ${token}`}
        });
        
        if (response.ok) {
            currentUser = await response.json();
            loadApp();
        } else {
            localStorage.removeItem('echolink_token');
            authContainer.style.display = 'flex';
        }
    } catch (error) {
        localStorage.removeItem('echolink_token');
        authContainer.style.display = 'flex';
    }
}

function loadApp() {
    authContainer.style.display = 'none';
    appContainer.style.display = 'flex';
    
    document.getElementById('current-username').textContent = currentUser.username;
    
    if (currentUser.is_admin) {
        document.getElementById('admin-btn').style.display = 'block';
    }
    
    connectWebSocket();
    loadServers();
    setupEventListeners();
}

function connectWebSocket() {
    socket = io({
        transports: ['websocket', 'polling']
    });
    
    socket.on('connect', () => {
        socket.emit('authenticate', {token: token});
    });
    
    socket.on('authenticated', (data) => {
        console.log('Authenticated as', data.username);
    });
    
    socket.on('new_message', (message) => {
        if (currentChannel && message.channel_id === currentChannel.id) {
            displayMessage(message);
        }
    });
    
    socket.on('user_typing', (data) => {
        if (currentChannel && data.channel_id === currentChannel.id) {
            showTypingIndicator(data.username);
        }
    });
    
    socket.on('user_status', (data) => {
        updateUserStatus(data.user_id, data.status);
    });
}

async function loadServers() {
    try {
        const response = await fetch('/api/servers', {
            headers: {'Authorization': `Bearer ${token}`}
        });
        
        const servers = await response.json();
        const serversList = document.getElementById('servers-list');
        serversList.innerHTML = '';
        
        servers.forEach(server => {
            const serverIcon = document.createElement('div');
            serverIcon.className = 'server-icon';
            serverIcon.dataset.serverId = server.id;
            serverIcon.textContent = server.name[0].toUpperCase();
            serverIcon.addEventListener('click', () => loadServer(server));
            serversList.appendChild(serverIcon);
        });
    } catch (error) {
        console.error('Failed to load servers', error);
    }
}

async function loadServer(server) {
    currentServer = server;
    
    document.querySelectorAll('.server-icon').forEach(icon => {
        icon.classList.remove('active');
    });
    document.querySelector(`[data-server-id="${server.id}"]`).classList.add('active');
    
    document.getElementById('current-server-name').textContent = server.name;
    
    try {
        const response = await fetch(`/api/servers/${server.id}/channels`, {
            headers: {'Authorization': `Bearer ${token}`}
        });
        
        const channels = await response.json();
        const channelsList = document.getElementById('channels-list');
        channelsList.innerHTML = '<div class="channel-category">Text Channels</div>';
        
        const textChannels = channels.filter(c => c.type === 'text');
        const voiceChannels = channels.filter(c => c.type === 'voice');
        
        textChannels.forEach(channel => {
            const channelItem = document.createElement('div');
            channelItem.className = 'channel-item';
            channelItem.dataset.channelId = channel.id;
            channelItem.textContent = channel.name;
            channelItem.addEventListener('click', () => loadChannel(channel));
            channelsList.appendChild(channelItem);
        });
        
        if (voiceChannels.length > 0) {
            const voiceCategory = document.createElement('div');
            voiceCategory.className = 'channel-category';
            voiceCategory.textContent = 'Voice Channels';
            channelsList.appendChild(voiceCategory);
            
            voiceChannels.forEach(channel => {
                const channelItem = document.createElement('div');
                channelItem.className = 'channel-item voice';
                channelItem.dataset.channelId = channel.id;
                channelItem.textContent = channel.name;
                channelItem.addEventListener('click', () => loadChannel(channel));
                channelsList.appendChild(channelItem);
            });
        }
        
        if (textChannels.length > 0) {
            loadChannel(textChannels[0]);
        }
    } catch (error) {
        console.error('Failed to load channels', error);
    }
}

async function loadChannel(channel) {
    if (currentChannel) {
        socket.emit('leave_channel', {channel_id: currentChannel.id});
    }
    
    currentChannel = channel;
    
    document.querySelectorAll('.channel-item').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelector(`[data-channel-id="${channel.id}"]`).classList.add('active');
    
    document.getElementById('channel-name').textContent = `# ${channel.name}`;
    document.getElementById('message-input').placeholder = `Message #${channel.name}`;
    
    if (channel.type === 'voice') {
        document.getElementById('voice-toggle-btn').style.display = 'block';
    } else {
        document.getElementById('voice-toggle-btn').style.display = 'none';
    }
    
    socket.emit('join_channel', {channel_id: channel.id});
    
    try {
        const response = await fetch(`/api/channels/${channel.id}/messages`, {
            headers: {'Authorization': `Bearer ${token}`}
        });
        
        const messages = await response.json();
        const messagesContainer = document.getElementById('messages-container');
        messagesContainer.innerHTML = '';
        
        messages.forEach(message => displayMessage(message));
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    } catch (error) {
        console.error('Failed to load messages', error);
    }
}

function displayMessage(message) {
    const messagesContainer = document.getElementById('messages-container');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message';
    
    const timestamp = new Date(message.timestamp).toLocaleTimeString([], {hour: '2-digit', minute: '2-digit'});
    
    let attachmentHTML = '';
    if (message.attachments) {
        const ext = message.attachments.split('.').pop().toLowerCase();
        if (['png', 'jpg', 'jpeg', 'gif', 'webp'].includes(ext)) {
            attachmentHTML = `<div class="message-attachment"><img src="${message.attachments}" alt="Attachment"></div>`;
        } else {
            attachmentHTML = `<div class="message-attachment"><a href="${message.attachments}" target="_blank">📎 ${message.attachments.split('/').pop()}</a></div>`;
        }
    }
    
    messageDiv.innerHTML = `
        <div class="message-avatar">
            <img src="/static/images/${message.author.avatar}" alt="${message.author.username}">
        </div>
        <div class="message-content">
            <div class="message-header">
                <span class="message-author">${message.author.username}</span>
                <span class="message-timestamp">${timestamp}</span>
            </div>
            <div class="message-text">${escapeHtml(message.content)}</div>
            ${attachmentHTML}
        </div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function sendMessage() {
    const input = document.getElementById('message-input');
    const content = input.value.trim();
    
    if (!content || !currentChannel) return;
    
    socket.emit('send_message', {
        channel_id: currentChannel.id,
        content: content
    });
    
    input.value = '';
}

function setupEventListeners() {
    document.getElementById('send-btn').addEventListener('click', sendMessage);
    
    document.getElementById('message-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        } else {
            if (currentChannel) {
                clearTimeout(typingTimeout);
                socket.emit('typing', {channel_id: currentChannel.id});
                typingTimeout = setTimeout(() => {}, 3000);
            }
        }
    });
    
    document.getElementById('add-server-btn').addEventListener('click', async () => {
        const name = prompt('Enter server name:');
        if (name) {
            try {
                const response = await fetch('/api/servers', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({name})
                });
                
                if (response.ok) {
                    loadServers();
                }
            } catch (error) {
                console.error('Failed to create server', error);
            }
        }
    });
    
    document.getElementById('attach-btn').addEventListener('click', () => {
        document.getElementById('file-input').click();
    });
    
    document.getElementById('file-input').addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        const formData = new FormData();
        formData.append('file', file);
        
        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                headers: {'Authorization': `Bearer ${token}`},
                body: formData
            });
            
            const data = await response.json();
            if (data.url && currentChannel) {
                socket.emit('send_message', {
                    channel_id: currentChannel.id,
                    content: file.name,
                    attachments: data.url
                });
            }
        } catch (error) {
            console.error('Upload failed', error);
        }
        
        e.target.value = '';
    });
    
    if (currentUser && currentUser.is_admin) {
        document.getElementById('admin-btn').addEventListener('click', () => {
            loadAdminPanel();
        });
        
        document.getElementById('close-admin').addEventListener('click', () => {
            document.getElementById('admin-panel').style.display = 'none';
        });
        
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const tab = btn.dataset.tab;
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                document.querySelectorAll('.admin-tab-content').forEach(content => {
                    content.style.display = 'none';
                });
                document.getElementById(`admin-${tab}`).style.display = 'block';
                
                if (tab === 'servers') {
                    loadAdminServers();
                }
            });
        });
    }
}

async function loadAdminPanel() {
    document.getElementById('admin-panel').style.display = 'flex';
    
    try {
        const response = await fetch('/api/admin/users', {
            headers: {'Authorization': `Bearer ${token}`}
        });
        
        const users = await response.json();
        const usersList = document.getElementById('users-list');
        usersList.innerHTML = '';
        
        users.forEach(user => {
            const userItem = document.createElement('div');
            userItem.className = 'admin-item';
            userItem.innerHTML = `
                <div class="admin-item-info">
                    <h4>${user.username}</h4>
                    <p>${user.email} | Status: ${user.status} | Verified: ${user.is_verified ? 'Yes' : 'No'}</p>
                </div>
                <button class="btn-danger" onclick="deleteUser(${user.id})">Delete</button>
            `;
            usersList.appendChild(userItem);
        });
    } catch (error) {
        console.error('Failed to load admin users', error);
    }
}

async function loadAdminServers() {
    try {
        const response = await fetch('/api/admin/servers', {
            headers: {'Authorization': `Bearer ${token}`}
        });
        
        const servers = await response.json();
        const serversList = document.getElementById('admin-servers-list');
        serversList.innerHTML = '';
        
        servers.forEach(server => {
            const serverItem = document.createElement('div');
            serverItem.className = 'admin-item';
            serverItem.innerHTML = `
                <div class="admin-item-info">
                    <h4>${server.name}</h4>
                    <p>Members: ${server.member_count} | Created: ${new Date(server.created_at).toLocaleDateString()}</p>
                </div>
                <button class="btn-danger" onclick="deleteServer(${server.id})">Delete</button>
            `;
            serversList.appendChild(serverItem);
        });
    } catch (error) {
        console.error('Failed to load admin servers', error);
    }
}

async function deleteUser(userId) {
    if (!confirm('Are you sure you want to delete this user?')) return;
    
    try {
        await fetch('/api/admin/users', {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({user_id: userId})
        });
        
        loadAdminPanel();
    } catch (error) {
        console.error('Failed to delete user', error);
    }
}

async function deleteServer(serverId) {
    if (!confirm('Are you sure you want to delete this server?')) return;
    
    try {
        await fetch('/api/admin/servers', {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({server_id: serverId})
        });
        
        loadAdminServers();
        loadServers();
    } catch (error) {
        console.error('Failed to delete server', error);
    }
}

function showTypingIndicator(username) {
    const indicator = document.getElementById('typing-indicator');
    indicator.textContent = `${username} is typing...`;
    indicator.style.display = 'block';
    
    setTimeout(() => {
        indicator.style.display = 'none';
    }, 3000);
}

function updateUserStatus(userId, status) {
    console.log(`User ${userId} is now ${status}`);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
