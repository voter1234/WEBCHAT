let peerConnection = null;
let localStream = null;
let isInVoiceChannel = false;
let remoteStreams = {};

const voiceToggleBtn = document.getElementById('voice-toggle-btn');

if (voiceToggleBtn) {
    voiceToggleBtn.addEventListener('click', toggleVoiceChat);
}

async function toggleVoiceChat() {
    if (!isInVoiceChannel) {
        await joinVoiceChannel();
    } else {
        leaveVoiceChannel();
    }
}

async function joinVoiceChannel() {
    if (!currentChannel || currentChannel.type !== 'voice') {
        alert('Please select a voice channel first');
        return;
    }
    
    try {
        localStream = await navigator.mediaDevices.getUserMedia({
            audio: {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true
            }
        });
        
        isInVoiceChannel = true;
        voiceToggleBtn.textContent = '🔇 Leave Voice';
        voiceToggleBtn.classList.add('active');
        
        setupPeerConnection();
        
        socket.on('voice_signal', handleVoiceSignal);
        
        console.log('Joined voice channel');
    } catch (error) {
        console.error('Failed to access microphone:', error);
        alert('Could not access microphone. Please check permissions.');
    }
}

function leaveVoiceChannel() {
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
        localStream = null;
    }
    
    if (peerConnection) {
        peerConnection.close();
        peerConnection = null;
    }
    
    Object.values(remoteStreams).forEach(stream => {
        stream.getTracks().forEach(track => track.stop());
    });
    remoteStreams = {};
    
    isInVoiceChannel = false;
    voiceToggleBtn.textContent = '🎤 Join Voice';
    voiceToggleBtn.classList.remove('active');
    
    socket.off('voice_signal', handleVoiceSignal);
    
    console.log('Left voice channel');
}

function setupPeerConnection() {
    const configuration = {
        iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' }
        ]
    };
    
    peerConnection = new RTCPeerConnection(configuration);
    
    localStream.getTracks().forEach(track => {
        peerConnection.addTrack(track, localStream);
    });
    
    peerConnection.ontrack = (event) => {
        const [remoteStream] = event.streams;
        playRemoteAudio(remoteStream);
    };
    
    peerConnection.onicecandidate = (event) => {
        if (event.candidate && currentChannel) {
            socket.emit('voice_signal', {
                channel_id: currentChannel.id,
                type: 'ice-candidate',
                candidate: event.candidate
            });
        }
    };
    
    peerConnection.onnegotiationneeded = async () => {
        try {
            const offer = await peerConnection.createOffer();
            await peerConnection.setLocalDescription(offer);
            
            if (currentChannel) {
                socket.emit('voice_signal', {
                    channel_id: currentChannel.id,
                    type: 'offer',
                    sdp: peerConnection.localDescription
                });
            }
        } catch (error) {
            console.error('Error during negotiation:', error);
        }
    };
}

async function handleVoiceSignal(data) {
    if (!peerConnection) {
        setupPeerConnection();
    }
    
    try {
        if (data.type === 'offer') {
            await peerConnection.setRemoteDescription(new RTCSessionDescription(data.sdp));
            const answer = await peerConnection.createAnswer();
            await peerConnection.setLocalDescription(answer);
            
            socket.emit('voice_signal', {
                channel_id: currentChannel.id,
                type: 'answer',
                sdp: peerConnection.localDescription
            });
        } else if (data.type === 'answer') {
            await peerConnection.setRemoteDescription(new RTCSessionDescription(data.sdp));
        } else if (data.type === 'ice-candidate') {
            await peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
        }
    } catch (error) {
        console.error('Error handling voice signal:', error);
    }
}

function playRemoteAudio(stream) {
    const audio = new Audio();
    audio.srcObject = stream;
    audio.autoplay = true;
    audio.volume = 1.0;
    
    const streamId = stream.id;
    remoteStreams[streamId] = stream;
    
    stream.addEventListener('removetrack', () => {
        delete remoteStreams[streamId];
        audio.srcObject = null;
    });
}
